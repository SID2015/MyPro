﻿using System;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using static Microsoft.AspNetCore.Hosting.Internal.HostingApplication;

namespace StudentData.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new StudentDataContext(
                serviceProvider.GetRequiredService<DbContextOptions<StudentDataContext>>()))
            {
                if (context.Students.Any())
                {
                    return;
                }

                context.Students.AddRange(

                    new Students
                    {
                       
                        Name = "Shailendra Singh ",
                        DateOfBirth = DateTime.Parse("1994-06-10"),
                        Marks = 71,
                        Branch = "Computer Science Engineer",
                        Address = "Shastri Nagar , Ajmer"
                    },

                    new Students
                    {
                      
                        Name = "Nikhil Singh ",
                        DateOfBirth = DateTime.Parse("1993-06-17"),
                        Marks = 77,
                        Branch = "Mechanical Engineer",
                        Address = "Mansarovar , Jaipur"
                    },

                    new Students
                    {
                      
                        Name = "Vikas Kumar  ",
                        DateOfBirth = DateTime.Parse("1995-02-05"),
                        Marks = 68,
                        Branch = "Electronics And Communications Engineer",
                        Address = "Shahdra , Delhi"
                    }
                );

                context.SaveChanges();











            }
        }
    }
}
